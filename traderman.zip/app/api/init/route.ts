import { NextResponse } from "next/server";
import { initializeApp } from "@/lib/app-startup.server";

export async function GET() {
  try {
    console.log("[v0] Init API called");
    console.log("[v0] Starting app initialization...");
    await initializeApp();
    console.log("[v0] App initialization completed successfully");
    return NextResponse.json({ success: true, message: "App initialized" });
  } catch (error) {
    console.error("[v0] Failed to initialize app:", error);
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error";
    console.error("[v0] Error details:", errorMessage);
    return NextResponse.json(
      {
        error: "Failed to initialize app",
        details: errorMessage,
      },
      { status: 500 }
    );
  }
}
