import { NextResponse } from "next/server";

export async function POST() {
  try {
    console.log("[v0] Start API called");

    const settingsResponse = await fetch(
      `${
        process.env.VERCEL_URL
          ? "https://" + process.env.VERCEL_URL
          : "http://localhost:3000"
      }/api/settings`
    );

    let settings = { schedulerEnabled: true };
    if (settingsResponse.ok) {
      settings = await settingsResponse.json();
    }

    if (!settings.schedulerEnabled) {
      return NextResponse.json(
        { error: "Scheduler is disabled in settings" },
        { status: 400 }
      );
    }

    await fetch(
      `${
        process.env.VERCEL_URL
          ? "https://" + process.env.VERCEL_URL
          : "http://localhost:3000"
      }/api/settings`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...settings, schedulerRunning: true }),
      }
    );

    console.log("[v0] Start API success");
    return NextResponse.json({ success: true, message: "Scheduler started" });
  } catch (error) {
    console.error("[v0] Start API error:", error);
    return NextResponse.json(
      {
        error: "Failed to start scheduler",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}
