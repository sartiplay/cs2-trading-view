import { NextResponse } from "next/server";

function calculateNextExecution(
  cronExpression: string,
  timezone: string
): Date {
  const now = new Date();

  // For daily execution (0 0 * * *)
  if (cronExpression === "0 0 * * *") {
    const next = new Date(now);
    next.setHours(0, 0, 0, 0);
    next.setDate(now.getDate() + 1);
    return next;
  }

  // For interval-based execution (*/X * * * *)
  const match = cronExpression.match(/^\*\/(\d+) \* \* \* \*$/);
  if (match) {
    const intervalMinutes = Number.parseInt(match[1]);
    const next = new Date(now);
    const minutesPassed = now.getMinutes() % intervalMinutes;
    next.setMinutes(now.getMinutes() + (intervalMinutes - minutesPassed));
    next.setSeconds(0);
    next.setMilliseconds(0);
    return next;
  }

  // Fallback to next hour
  const next = new Date(now);
  next.setHours(now.getHours() + 1, 0, 0, 0);
  return next;
}

export async function GET() {
  try {
    console.log("[v0] Status API called");

    const settingsResponse = await fetch(
      `${
        process.env.VERCEL_URL
          ? "https://" + process.env.VERCEL_URL
          : "http://localhost:3000"
      }/api/settings`
    );

    let settings = {
      schedulerEnabled: true,
      schedulerRunning: false,
      cronDelayMinutes: 1440,
      fetchDelayMs: 2000,
      timezone: "Europe/Zurich",
    };

    if (settingsResponse.ok) {
      settings = await settingsResponse.json();
    }

    const cronExpression =
      (settings.cronDelayMinutes || 1440) === 1440
        ? "0 0 * * *"
        : `*/${settings.cronDelayMinutes || 1440} * * * *`;

    const nextExecution = calculateNextExecution(
      cronExpression,
      settings.timezone || "Europe/Zurich"
    );

    const status = {
      running: settings.schedulerRunning || false,
      enabled: settings.schedulerEnabled !== false,
      timezone: settings.timezone || "Europe/Zurich",
      intervalMinutes: settings.cronDelayMinutes || 1440,
      fetchDelayMs: settings.fetchDelayMs || 2000,
      cronExpression,
      nextExecution: nextExecution.toISOString(), // Added next execution time
    };

    console.log("[v0] Status API returning:", status);
    return NextResponse.json(status);
  } catch (error) {
    console.error("[v0] Status API error:", error);

    const fallbackNext = new Date();
    fallbackNext.setDate(fallbackNext.getDate() + 1);
    fallbackNext.setHours(0, 0, 0, 0);

    return NextResponse.json({
      running: false,
      enabled: true,
      timezone: "Europe/Zurich",
      intervalMinutes: 1440,
      fetchDelayMs: 2000,
      cronExpression: "0 0 * * *",
      nextExecution: fallbackNext.toISOString(),
    });
  }
}
