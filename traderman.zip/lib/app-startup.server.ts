import { startScheduler } from "./scheduler.server";

let initialized = false;

export async function initializeApp() {
  try {
    console.log("[v0] MINIMAL: Starting app initialization...");

    if (initialized) {
      console.log("[v0] MINIMAL: Already initialized, skipping");
      return;
    }

    console.log("[v0] MINIMAL: About to start scheduler...");
    await startScheduler();
    console.log("[v0] MINIMAL: Scheduler started");

    initialized = true;
    console.log("[v0] MINIMAL: App initialization complete");
  } catch (error) {
    console.error("[v0] MINIMAL: App initialization failed:", error);
    console.error(
      "[v0] MINIMAL: Error details:",
      error instanceof Error ? error.message : "Unknown error"
    );
    throw error;
  }
}

export function isAppInitialized(): boolean {
  return initialized;
}
