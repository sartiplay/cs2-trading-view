import { readFile, writeFile, mkdir } from "fs/promises";
import { join } from "path";

const SETTINGS_DIR = join(process.cwd(), "");
const SETTINGS_FILE = join(SETTINGS_DIR, "settings.json");

export interface AppSettings {
  timelineResolution: "5min" | "30min" | "1h" | "4h" | "1d";
  cronDelayMinutes: number;
  fetchDelayMs: number;
  discordWebhookEnabled: boolean;
  discordWebhookUrl: string;
  discordDevelopmentMode: boolean;
  schedulerEnabled: boolean;
  schedulerRunning: boolean;
}

const defaultSettings: AppSettings = {
  timelineResolution: "1d",
  cronDelayMinutes: 1440,
  fetchDelayMs: 2000,
  discordWebhookEnabled: false,
  discordWebhookUrl: "",
  discordDevelopmentMode: false,
  schedulerEnabled: true,
  schedulerRunning: false,
};

export async function loadSettings(): Promise<AppSettings> {
  try {
    await mkdir(SETTINGS_DIR, { recursive: true });
    const data = await readFile(SETTINGS_FILE, "utf-8");
    const settings = JSON.parse(data);
    return settings;
  } catch (error) {
    console.log("[Settings] File not found, using defaults");
    return defaultSettings;
  }
}

export async function saveSettings(settings: AppSettings): Promise<void> {
  try {
    await mkdir(SETTINGS_DIR, { recursive: true });
    await writeFile(SETTINGS_FILE, JSON.stringify(settings, null, 2));
    console.log("[Settings] Saved successfully");
  } catch (error) {
    console.error("[Settings] Failed to save:", error);
    throw error;
  }
}

export async function updateSchedulerState(
  running: boolean,
  enabled?: boolean
): Promise<void> {
  const settings = await loadSettings();
  settings.schedulerRunning = running;
  if (enabled !== undefined) {
    settings.schedulerEnabled = enabled;
  }
  await saveSettings(settings);
}
