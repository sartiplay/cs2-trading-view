import { Settings } from "@/app/api/settings/route";

// Simple in-memory scheduler state
let schedulerRunning = false;

// Helper function to get settings from the API
async function getSettings() {
  try {
    const response = await fetch(
      `${
        process.env.VERCEL_URL
          ? "https://" + process.env.VERCEL_URL
          : "http://localhost:3000"
      }/api/settings`
    );
    if (response.ok) {
      return await response.json();
    }
  } catch (error) {
    console.error("[v0] Error fetching settings:", error);
  }

  // Return default settings if fetch fails
  return {
    timezone: "Europe/Zurich",
    intervalMinutes: 1440,
    fetchDelayMs: 2000,
    schedulerRunning: false,
    schedulerEnabled: false,
    cronExpression: "0 0 * * *",
  };
}

// Helper function to update settings
async function updateSettings(updates: any) {
  try {
    const currentSettings = await getSettings();
    const response = await fetch(
      `${
        process.env.VERCEL_URL
          ? "https://" + process.env.VERCEL_URL
          : "http://localhost:3000"
      }/api/settings`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...currentSettings, ...updates }),
      }
    );
    return response.ok;
  } catch (error) {
    console.error("[v0] Error updating settings:", error);
    return false;
  }
}

export async function startScheduler() {
  try {
    console.log("[v0] Starting scheduler...");
    schedulerRunning = true;

    const settings = await getSettings();
    if (!settings.schedulerEnabled) {
      console.log("[v0] Scheduler is disabled in settings");
      return;
    }

    await updateSettings({ schedulerRunning: true, schedulerEnabled: true });

    console.log("[v0] Scheduler started successfully");
  } catch (error) {
    console.error("[v0] Error starting scheduler:", error);
    schedulerRunning = false;
    throw error;
  }
}

export async function stopScheduler() {
  try {
    console.log("[v0] Stopping scheduler...");
    schedulerRunning = false;

    await updateSettings({ schedulerRunning: false, schedulerEnabled: false });

    console.log("[v0] Scheduler stopped successfully");
  } catch (error) {
    console.error("[v0] Error stopping scheduler:", error);
    schedulerRunning = true;
    throw error;
  }
}

export async function restartScheduler() {
  console.log("[v0] Restarting scheduler...");
  await stopScheduler();
  await startScheduler();
}

export async function getSchedulerStatus() {
  try {
    console.log("[v0] Getting scheduler status...");

    const settings: Settings = await getSettings();

    const status = {
      running: settings.schedulerRunning,
      enabled: settings.schedulerEnabled || false,
      timezone: "Europe/Zurich",
      intervalMinutes: settings.cronDelayMinutes || 1440,
      fetchDelayMs: settings.fetchDelayMs || 2000,
      cronExpression:
        settings.cronDelayMinutes === 1440
          ? "0 0 * * *"
          : `*/${settings.cronDelayMinutes} * * * *`,
    };

    console.log("[v0] Status:", status);
    return status;
  } catch (error) {
    console.error("[v0] Error getting status:", error);
    return {
      running: false,
      enalbed: true,
      timezone: "Europe/Zurich",
      intervalMinutes: 1440,
      fetchDelayMs: 2000,
      cronExpression: "0 0 * * *",
    };
  }
}
